package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class ShirtsPage {
	
public WebDriver driver;
	
	public ShirtsPage(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}
	
	@FindBy(xpath="//img[@title='Red']")
	WebElement Redcolor;
	
	@FindBy(xpath="//span[@class='swatch-label']/img[@alt='Red']")
	WebElement charcolColor;
	
	@FindBy(xpath="//a[@id='swatch78']")
	WebElement LSize;
	
	@FindBy(xpath="//a[text()='View Details']")
	WebElement viewDetails;
	
	@FindBy(xpath="//div[@class='add-to-cart-buttons']/button/span")
	WebElement AddToCart;
	
	@FindBy(xpath="//li[@class='success-msg']/ul/li")
	WebElement SuccessMsg;
	
	@FindBy(xpath="//li[@class='method-checkout-cart-methods-onepage-bottom']/button")
	WebElement ProcessedToCheckout;
	
	
	
	public void SelectColor() throws InterruptedException
	{
		Redcolor.click();
		Thread.sleep(2000);
	}
	public void ClickonViewDetails() throws InterruptedException
	{
		Thread.sleep(2000);
		viewDetails.click();
	}
	public void SelectColorSizeAndAddToCart() throws InterruptedException
	{
		Thread.sleep(2000);
		LSize.click();
		charcolColor.click();
		AddToCart.click();
	}
	public void ValidateSuccessMsg()
	{
		String expectedText="Plaid Cotton Shirt was added to your shopping cart.";
		String actualText=SuccessMsg.getText();
		Assert.assertEquals(actualText, expectedText, "success Message Verified");
		if(actualText.equals(expectedText))
		{
			System.out.println("Add Cart success Message Verified");
		}
		else
		{
			System.out.println("Add Cart Success msg not displayed");
		}
	}
	
	public void ClickOnProcessedToCheckout()
	{
		
		ProcessedToCheckout.click();
	}
	
	
	

}
