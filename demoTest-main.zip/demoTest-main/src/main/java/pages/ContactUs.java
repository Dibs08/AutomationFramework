package pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class ContactUs {
	
	
public WebDriver driver;
	
	public ContactUs(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver,this);
		}
	
	@FindBy(xpath="//a[text()='Contact Us']")
	WebElement contactUs; 
	
	@FindBy(xpath="//input[@id='name']")
	WebElement nameInputBox;
	
	@FindBy(xpath="//input[@id='email']")
	WebElement emailInputBox;
	
	@FindBy(xpath="//*[@id='comment']")
	WebElement CommentInputbox;
	
	@FindBy(xpath="//div[@class='buttons-set']/button/span")
	WebElement SubmitBtn; 
	
	@FindBy(xpath="//li[@class='error-msg']/ul/li")
	WebElement message;
	
	public void clickOnContactUs()
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,950)", "");
		contactUs.click();
	}
	public void dataEntry(String name, String email, String comment)
	{
		nameInputBox.sendKeys(name);
		emailInputBox.sendKeys(email);
		CommentInputbox.sendKeys(comment);
	}
	public void ClickOnsubmit()
	{
		SubmitBtn.click();
	}
	
	public void ValidateSuccessMsg()
	{
		String expectedText="Unable to submit your request. Please, try again later";
		String actualText=message.getText();
		Assert.assertEquals(actualText, expectedText);
		if(actualText.equals(expectedText))
		{
			System.out.println("Failure Message Successfully Displayed");
		}
		else
		{
			System.out.println("Failure Message Successfully Not Displayed");
		}
	}
			

}
