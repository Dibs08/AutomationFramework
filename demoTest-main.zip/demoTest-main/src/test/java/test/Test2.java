package test;

import java.beans.ConstructorProperties;
import java.util.Properties;

import org.testng.annotations.Test;

import pages.ContactUs;
import pages.HomePage;


 // 1. Go to contactUS page
 // 2. Fill the required Details
 // 3. submit the details(wrong data)
 // 4. Verify the Failure message of submit request

public class Test2 extends BaseTest {
	
	
	@Test
	public void goToCartAndRemoveProductAndAddNewProduct()
    {
		ContactUs ContactUs = new ContactUs(driver);
		ContactUs.clickOnContactUs();
     	ContactUs.dataEntry("Dibyendu", "dkkjsjk@email.com", "Hi Sir");
     	ContactUs.ClickOnsubmit();
     	ContactUs.ValidateSuccessMsg();
    	
    }

}
