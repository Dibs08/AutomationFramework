package test;

import org.testng.annotations.Test;


// 1. Navigate to product page
// 2. Select any product
// 3. Select the color and size and click view details
// 4. Verify the message Success Message

import pages.HomePage;
import pages.ShirtsPage;

//1.go to homepage
//2. moved to Men and select the Shirts
//3. GO to product details Page
//4. select the color, size and add to cart
//5. validate the add to cart success message


public class Test1 extends BaseTest
{

    @Test()
    public void selectProductandValidateSucessMsg() throws InterruptedException
    {
    	HomePage homepage = new HomePage(driver);    
        homepage.navigateToProductPage();
        ShirtsPage shirt=new ShirtsPage(driver);
    	shirt.SelectColor();
    	shirt.ClickonViewDetails();
    	shirt.SelectColorSizeAndAddToCart();
    	shirt.ValidateSuccessMsg();
    	
    }

}